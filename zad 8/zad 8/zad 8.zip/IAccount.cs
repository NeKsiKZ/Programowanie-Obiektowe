﻿using System.Collections.Generic;

public interface IAccount
{
    decimal GetBalance();
}
